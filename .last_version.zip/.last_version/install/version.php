<?
$arModuleVersion = array(
	"VERSION" => "0.1.0",
	"VERSION_DATE" => "2021-02-04 09:00:00"
);
?>